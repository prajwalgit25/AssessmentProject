package Tests;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class RegistrationStepDefinition {
	
	
	WebDriver driver;
	
	
	@Given("^User goes to http://automationpractice\\.com/index\\.php$")
	public void GoToRegistrationPage() throws Throwable {
		
		 
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Acer\\Desktop\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
		driver.navigate().to("http://automationpractice.com/index.php");
		
		driver.manage().window().maximize();
		
		
		
	   
	}

	@When("^User clicks on SignIn button$")
	public void user_clicks_on_SignIn_button() throws Throwable {
		
		Thread.sleep(5000);
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click(); 
		
	
	}

	@Then("^SignIn page should be displayed$")
	public void signin_page_should_be_displayed() throws Throwable {
	    
		Thread.sleep(5000);    
	}

	@Then("^User enters the valid email id in email address text box$")
	public void user_enters_the_valid_email_id_in_email_address_text_box() throws Throwable {
		
		driver.findElement(By.xpath("//*[@id='email_create']")).sendKeys("sudarshana@vtestcorp.com");
		
		}

	@When("^User clicks on the create an account button$")
	public void user_clicks_on_the_create_an_account_button() throws Throwable {
	   
		driver.findElement(By.xpath("//*[@id='SubmitCreate']")).click();
	    
	}

	@SuppressWarnings("deprecation")
	@Then("^Registration page should be displayed\\.$")
	public void registration_page_should_be_displayed() throws Throwable {
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//input[@type='radio']")).click();
	   
		
		driver.findElement(By.xpath("//*[@id='customer_firstname']")).sendKeys("Patrick");
		
		driver.findElement(By.xpath("//*[@id='customer_lastname']")).sendKeys("George");
		
		driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("giriffindor@123456");
		
		Thread.sleep(5000);
		
		driver.findElement(By.xpath("//*[@id='firstname']")).sendKeys("Patrick");
		
		driver.findElement(By.xpath("//*[@id='lastname']")).sendKeys("George");
		
		driver.findElement(By.xpath("//*[@id='address1']")).sendKeys("1234 street");
		
		driver.findElement(By.xpath("//*[@id='city']")).sendKeys("Newyork");
		
		WebElement ele=driver.findElement(By.xpath("//*[@id='id_state']"));
		Select se= new Select(ele);
		se.selectByIndex(6);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id='postcode']")).sendKeys("10003");
		
		WebElement ele1=driver.findElement(By.xpath("//*[@id='id_country']"));
		Select se1= new Select(ele1);
		se1.selectByIndex(1);
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id='phone_mobile']")).sendKeys("0123456789");
		
		
		driver.findElement(By.xpath("//*[@id='submitAccount']")).click();
		
		String name=driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a/span")).getText();
		
		Assert.assertEquals("nameverfied","Patrick George", name);
		
		System.out.print(name);
		
		Thread.sleep(3000);
		
		
	}
	
	@Then("^User clicks on Sigout link$")
	public void user_clicks_on_Sigout_link() throws Throwable
	{
	
		driver.findElement(By.xpath("//*[@class='logout']")).click();
	
		driver.close();
	}
	
	
	
	@Given("^User goes to website$")
	public void user_goes_to_website() throws Throwable {
		
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Acer\\Desktop\\chromedriver.exe");
		
		driver=new ChromeDriver();
		
		driver.navigate().to("http://automationpractice.com/index.php");
		
		driver.manage().window().maximize();
		
		Thread.sleep(3000);
		
		driver.findElement(By.xpath("//*[@id='header']/div[2]/div/div/nav/div[1]/a")).click();
		
		Thread.sleep(3000);
		
	}
	
	@When("^User enters the valid email id and password$")
	
	public void user_enters_the_valid_email_id_and_password() throws Throwable {
		
	driver.findElement(By.xpath("//*[@id='email']")).sendKeys("sudarshana@vtestcorp.com");
	
	driver.findElement(By.xpath("//*[@id='passwd']")).sendKeys("giriffindor@123456");
	
	driver.findElement(By.xpath("//*[@id='SubmitLogin']")).click();
	
	Thread.sleep(3000);
	
	
	
	
	}
	
	@Then("^User is navigated to the My Account Page$")
	public void user_is_navigated_to_the_My_Account_Page() throws Throwable {
		
		Thread.sleep(3000);
		
		WebElement button= driver.findElement(By.xpath("//*[@title='T-shirts']"));
		
		JavascriptExecutor js=((JavascriptExecutor) driver);
		
		js.executeScript("arguments[0].click();",button);
		
		
		Thread.sleep(3000);
		
		
	    
	   
	}

	@Then("^User add a product to the cart$")
	public void user_add_a_product_to_the_cart() throws Throwable {
		
		JavascriptExecutor js=((JavascriptExecutor) driver);
		js.executeScript("window.scrollBy(0,1000)");
		
		Thread.sleep(3000);
		
		
		
		Actions action= new Actions(driver);
		
	WebElement element= driver.findElement(By.xpath("//*[@class='ajax_block_product col-xs-12 col-sm-6 col-md-4 first-in-line last-line first-item-of-tablet-line first-item-of-mobile-line last-mobile-line']"));
		
			action.moveToElement(element).perform();
		
		
    driver.findElement(By.xpath("//*[text()='Add to cart']")).click();
    
    Thread.sleep(3000);
    
    
    driver.findElement(By.xpath("//*[@class='btn btn-default button button-medium']")).click();
    
    Thread.sleep(3000);
    
    JavascriptExecutor js1=((JavascriptExecutor) driver);
	js1.executeScript("window.scrollBy(0,1000)");
	
	Thread.sleep(3000);
    
    
	

	
	
	
	
	

    driver.findElement(By.xpath("//*[@class='button btn btn-default standard-checkout button-medium']")).click();
    
    Thread.sleep(3000);
    
    JavascriptExecutor js2=((JavascriptExecutor) driver);
	js2.executeScript("window.scrollBy(0,1000)");
    
    driver.findElement(By.xpath("//*[@class='button btn btn-default button-medium']")).click();	
    
    JavascriptExecutor js3=((JavascriptExecutor) driver);
	js3.executeScript("window.scrollBy(0,1000)");
	
		
	
	Thread.sleep(3000);
	
	driver.findElement(By.xpath("//input[@type='checkbox']")).click();
	
	
	driver.findElement(By.xpath("//*[@class='button btn btn-default standard-checkout button-medium']")).click();	
	
	Thread.sleep(3000);
	
	JavascriptExecutor js4=((JavascriptExecutor) driver);
	js4.executeScript("window.scrollBy(0,1000)");
	
	
	
	
String price=driver.findElement(By.xpath("//*[@id='total_price']")).getText();
	
	Assert.assertEquals("priceverfied","$18.51", price);
	
	System.out.print(price);
	
	driver.close();
	
	driver.quit();
	
	
	
    
    
    
    
    
	    

	}
	
}
	
	
